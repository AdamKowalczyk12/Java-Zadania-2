package com.company;

import java.util.concurrent.ThreadLocalRandom;

public class Main {

    public static String losoweNazwisko(){
        int d = ThreadLocalRandom.current().nextInt(3,16);

        String nazwisko = "";

        for (int i = 0; i < d; i++){
            char c = (char)ThreadLocalRandom.current().nextInt(97,123);
            nazwisko += c;
        }

        return nazwisko;
    }

    public static int index(String[] t, String v){
        for(int i = 0; i < t.length; i++){
            if(t[i].equals(v)){
                return i;
            }
        }

        return -1;
    }

    public static int porownanie(Pracownik p1, Pracownik p2, int k)
    {
        String[] stanowiska = { "młodszy specjalista", "starszy specjalista", "księgowy", "manager", "kierownik" };

        if(k == 0)
        {
            return p1.getNazwisko().compareTo(p2.getNazwisko());
        }
        else if(k == 1){
            return index(stanowiska,p1.getStanowisko()) - index(stanowiska,p2.getStanowisko());
        }
        else {
            if(p1.getPensja() > p2.getPensja()){
                return 1;
            }
            else if(p1.getPensja() == p2.getPensja()){
                return 0;
            }
            else {
                return -1;
            }
        }
    }

    public static void Ranking(Pracownik[] firma, int klucz)
    {
        int zamiany = 1;

        while (zamiany > 0){ //sortowanie bąbelkowe
            zamiany = 0;

            for(int i = 1; i < firma.length; i++){
                if(porownanie(firma[i-1],firma[i],klucz) > 0){
                    Pracownik temp = firma[i-1];
                    firma[i-1] = firma[i];
                    firma[i] = temp;
                    zamiany++;
                }
            }
        }
    }

    public static void main(String[] args) {

        String[] imiona = { "Adam", "Andrzej", "Anna", "Monika", "Jan", "Krzysztof", "Maciej", "Michał", "Robert", "Agnieszka", "Zbigniew" };
        String[] stanowiska = { "młodszy specjalista", "starszy specjalista", "księgowy" };

        Pracownik[] pracownicy = new Pracownik[15];
        int pi = 0;

        int ileKierownikow = ThreadLocalRandom.current().nextInt(0,4);

        for(int i = 0; i < ileKierownikow; i++){
            int im = ThreadLocalRandom.current().nextInt(0,imiona.length);
            String imie = imiona[im];
            String nazwisko = losoweNazwisko();
            int staz = ThreadLocalRandom.current().nextInt(0,26);

            Pracownik p = new Pracownik(imie,nazwisko,"kierownik",staz,0);
            p.ustalPensje();
            pracownicy[pi] = p;
            pi++;
        }

        int ileManagerow = ThreadLocalRandom.current().nextInt(0,11);

        for(int i = 0; i < ileManagerow; i++) {
            int im = ThreadLocalRandom.current().nextInt(0,imiona.length);
            String imie = imiona[im];
            String nazwisko = losoweNazwisko();
            int staz = ThreadLocalRandom.current().nextInt(0,26);

            Pracownik p = new Pracownik(imie,nazwisko,"manager",staz,0);
            p.ustalPensje();
            pracownicy[pi] = p;
            pi++;
        }

        int zostalo = 15 - ileKierownikow - ileManagerow;

        for(int i = 0; i < zostalo; i++)
        {
            int im = ThreadLocalRandom.current().nextInt(0,imiona.length);
            String imie = imiona[im];
            String nazwisko = losoweNazwisko();
            int staz = ThreadLocalRandom.current().nextInt(0,26);
            int si = ThreadLocalRandom.current().nextInt(0,stanowiska.length);
            String stanowisko = stanowiska[si];

            Pracownik p = new Pracownik(imie,nazwisko,stanowisko,staz,0);
            p.ustalPensje();
            pracownicy[pi] = p;
            pi++;
        }


	    for(Pracownik p : pracownicy){
            System.out.println(p);
        }

        System.out.println("Posortowani po nazwisku");

	    Ranking(pracownicy,0);

        for(Pracownik p : pracownicy){
            System.out.println(p);
        }

        System.out.println("Posortowani po stanowisku");

        Ranking(pracownicy,1);

        for(Pracownik p : pracownicy){
            System.out.println(p);
        }

        System.out.println("Posortowani po pensji");

        Ranking(pracownicy,2);

        for(Pracownik p : pracownicy){
            System.out.println(p);
        }

        System.out.println("Pracownik konstruktor kopiujący:");

        Pracownik p1 = new Pracownik("Jan", "Nowakowski","manager",2,0);
        p1.ustalPensje();
        System.out.println(p1);

        Pracownik p2 = new Pracownik(p1);
        System.out.println(p2);
    }
}
