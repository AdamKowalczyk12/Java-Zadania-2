package com.company;

public class Pracownik {
    private String imie;
    private String nazwisko;
    private String stanowisko;
    private int stazPracy;
    private double pensja;

    public String getImie() {
        return imie;
    }

    public void setImie(String imie) {
        this.imie = imie;
    }

    public String getNazwisko() {
        return nazwisko;
    }

    public void setNazwisko(String nazwisko) {
        this.nazwisko = nazwisko;
    }

    public int getStazPracy() {
        return stazPracy;
    }

    public void setStazPracy(int stazPracy) {
        this.stazPracy = stazPracy;
    }

    public void zwiekszStaz(){
        stazPracy++;
        pensja += 150;

        if(pensja > 10000){
            pensja = 10000;
        }
    }

    public double getPensja() {
        return pensja;
    }

    public boolean ustalPensje(){
        pensja = 4500 + stazPracy * 150;

        if(stanowisko == "manager"){
            pensja += 500;
        }
        else if(stanowisko == "kierownik"){
            pensja += 1000;
        }

        if(pensja > 10000){
            pensja = 10000;
            return false;
        }

        return true;
    }

    public boolean zwiekszPensja(double wzrost){
        pensja *= (1+wzrost);

        pensja = Math.round(pensja*100.0)/100.0;

        if(pensja > 10000){
            pensja = 10000;
            return false;
        }
        else {
            return true;
        }
    }

    public String getStanowisko() {
        return stanowisko;
    }

    public void setStanowisko(String stanowisko) {
        this.stanowisko = stanowisko;
    }

    public Pracownik() {
        imie = "Jan";
        nazwisko = "Kowalski";
        stanowisko = "pracownik";
        stazPracy = 3;
        pensja = 4950;
    }

    public Pracownik(String imie, String nazwisko, String stanowisko, int stazPracy, double pensja) {
        this.imie = imie;
        this.nazwisko = nazwisko;
        this.stanowisko = stanowisko;
        this.stazPracy = stazPracy;
        this.pensja = pensja;
    }

    public Pracownik(Pracownik inny){
        this.imie = inny.imie;
        this.nazwisko = inny.nazwisko;
        this.stanowisko = inny.stanowisko;
        this.stazPracy = inny.stazPracy;
        this.pensja = inny.pensja;
    }

    @Override
    public String toString() {
        return "Pracownik{" +
                "imie='" + imie + '\'' +
                ", nazwisko='" + nazwisko + '\'' +
                ", stanowisko='" + stanowisko + '\'' +
                ", stazPracy=" + stazPracy +
                ", pensja=" + pensja +
                '}';
    }
}
